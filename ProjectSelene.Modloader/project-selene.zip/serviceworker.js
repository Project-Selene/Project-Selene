"use strict";
(() => {
  // src/serviceworker/serviceworker.ts
  var workers = /* @__PURE__ */ new Map();
  var callbacks = /* @__PURE__ */ new Map();
  var workerBroadcast = new BroadcastChannel("project-selene-worker-broadcast");
  workerBroadcast.addEventListener("message", (event) => {
    var _a, _b;
    if (((_a = event.data) == null ? void 0 : _a.type) === "response") {
      (_b = callbacks.get(event.data.id)) == null ? void 0 : _b(event.data);
    }
  });
  self.addEventListener("install", (event) => event.waitUntil((async () => {
    await self.skipWaiting();
  })()));
  self.addEventListener("activate", (event) => event.waitUntil((async () => {
    await self.clients.claim();
  })()));
  self.addEventListener("message", (event) => {
    var _a;
    (_a = event.source) == null ? void 0 : _a.postMessage({ type: "ok" });
    event.waitUntil((async () => {
      var _a2, _b, _c, _d;
      if (!(event.source instanceof Client)) {
        (_b = event.source) == null ? void 0 : _b.postMessage({ type: "error", sourceId: (_a2 = event == null ? void 0 : event.source) == null ? void 0 : _a2.id, message: "Can only process messages from clients" });
        return;
      }
      const data = event.data;
      const source = event.source;
      switch (data.type) {
        case "workers": {
          const reg = (_c = workers.get(source.id)) != null ? _c : { filter: [], workers: [], lastWorker: 0 };
          reg.workers = data.workers;
          workers.set(source.id, reg);
          source.postMessage({ type: "ok", sourceId: source.id });
          break;
        }
        case "filter": {
          const reg = (_d = workers.get(source.id)) != null ? _d : { filter: [], workers: [], lastWorker: 0 };
          reg.filter.push(data.start);
          workers.set(source.id, reg);
          source.postMessage({ type: "ok", sourceId: source.id });
          break;
        }
        default:
          source.postMessage({ type: "error", sourceId: source.id, message: "Unknown message type: " + data.type });
          break;
      }
    })());
  });
  self.addEventListener("fetch", (event) => event.respondWith((async () => {
    var _a;
    if (event.request.headers.get("Accept") === "text/event-stream") {
      return fetch(event.request);
    }
    const reg = workers.get(event.clientId);
    if (!reg) {
      return await fromNetworkOrCached(event.request);
    }
    for (const filter of reg.filter) {
      if (new URL(event.request.url).pathname.startsWith(filter)) {
        const next = (((_a = reg.lastWorker) != null ? _a : 0) + 1) % reg.workers.length;
        const worker = reg.workers[next];
        reg.lastWorker = next;
        const id = Math.random();
        const wait = waitForResponse(id);
        const stream = new TransformStream();
        worker.postMessage(
          {
            type: "fetch",
            id,
            request: {
              method: event.request.method,
              url: event.request.url,
              headers: toObject(event.request.headers),
              body: event.request.body,
              clientId: event.clientId
            },
            response: stream.writable
          },
          [
            stream.writable,
            ...event.request.body ? [event.request.body] : []
          ]
        );
        return new Response(
          stream.readable,
          (await wait).response
        );
      }
    }
    return await fromNetworkOrCached(event.request);
  })()));
  async function fromNetworkOrCached(request) {
    if (request.url.startsWith("chrome-extension")) {
      return fetch(request);
    }
    if (!navigator.onLine) {
      const cached = await caches.match(request);
      if (cached) {
        return cached;
      }
    }
    try {
      const response = await fetch(request);
      const cache = await caches.open("selene-loader");
      await cache.put(request, response.clone());
      return response;
    } catch (e) {
      const cached = await caches.match(request);
      if (cached) {
        return cached;
      }
      return new Response("Network error happened", {
        status: 408,
        headers: { "Content-Type": "text/plain" }
      });
    }
  }
  function toObject(headers) {
    const result = {};
    headers.forEach((value, key) => result[key] = value);
    return result;
  }
  function waitForResponse(id) {
    return new Promise((resolve) => callbacks.set(id, resolve));
  }
})();
//# sourceMappingURL=serviceworker.js.map
