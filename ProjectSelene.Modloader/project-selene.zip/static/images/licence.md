halo.png and juno.png:
They are not part of repository licence. You are allowed to use these in combination with this project (Project Selene).