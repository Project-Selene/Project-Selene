"use strict";
(() => {
  // src/prefix/prefix.ts
  function __injectClass(name, clazz) {
    const result = { [name]: class extends clazz {
    } }[name];
    for (const [name2, desc] of Object.entries(Object.getOwnPropertyDescriptors(clazz))) {
      if (!["name", "length", "prototype"].includes(name2)) {
        Object.defineProperty(result, name2, desc);
      }
    }
    Object.defineProperty(result, "name", { configurable: true, value: name });
    clazz = result;
    __projectSelene.classes[name] = clazz;
    return clazz;
  }
  function __injectFunction(name, value) {
    if (name === "startGame") {
      __projectSelene.functions[name] = value;
      return __projectSelene.gameReadyCallback;
    }
    __projectSelene.functions[name] = value;
    return value;
  }
  function __injectConst(name, value) {
    if (name === "tmp") {
      return value;
    }
    __projectSelene.consts[name] = value;
    return value;
  }
  function __injectLet(name, getter, setter) {
    if (name === "tmp") {
      return;
    }
    if (name in __projectSelene.lets) {
      console.warn("duplicate let", name);
    }
    __projectSelene.lets[name] = { getter, setter };
  }
  function __injectEnum(name, enumValue) {
    if (name === "tmp") {
      return;
    }
    if (name in __projectSelene.enums) {
      console.warn("duplicate enum", name);
    }
    __projectSelene.enums[name] = enumValue;
  }
  Object.assign(window, { __injectClass, __injectFunction, __injectConst, __injectLet, __injectEnum });
})();
//# sourceMappingURL=prefix.js.map
